
#ifndef mystack_h
#define mystack_h

	
#endif /* mystack_h */
